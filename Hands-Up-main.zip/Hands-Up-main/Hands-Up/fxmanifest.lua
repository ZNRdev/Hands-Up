fx_version 'cerulean'
game 'gta5'

description 'Non-Exploitable Hands Up'
version '1.0.0'

client_scripts {
    'client/*',
}