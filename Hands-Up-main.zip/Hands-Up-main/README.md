# Hands-Up
Non-Exploitable Hands Up

-Standalone Script 

-Runs At A 0.00 Resmon (Optimized) 

-Stops Players From Exploiting With Their Hands Up (When Putting Your Hands-Up The players Gun Gets Taken out of their hands So They Cant Shoot With Hands-Up Or Trying To Glitch Roll)
